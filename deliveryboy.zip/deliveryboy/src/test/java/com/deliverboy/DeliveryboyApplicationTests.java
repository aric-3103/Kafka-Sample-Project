package com.deliverboy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryboyApplicationTests {

	@Test
	void contextLoads() {
	}

}
